#include <catch.hpp>

#include "../Optional.h"

TEST_CASE("Create Optional", "[Optional]") {
    class MyObj {
        bool b;
    public:
        MyObj(int) : b(true) {
            printf("constructed\n");
        }
        MyObj(const MyObj &rhs) {
            b = rhs.b;
            printf("copied\n");
        }
        MyObj(MyObj &&rhs) {
            printf("moved\n");
            b = rhs.b;
            rhs.b = false;
        }
        ~MyObj() {
            if (b) {
                printf("destroyed\n");
            }
        }
    };

    sys::Optional<MyObj> v1;
    REQUIRE_FALSE(v1.initialized());
    sys::Optional<MyObj> v2(MyObj(11));
    REQUIRE(v2.initialized());
    v1 = v2;
    REQUIRE(v1.initialized());
    REQUIRE(v2.initialized());
    v1 = v1;
    REQUIRE(v1.initialized());
    v1 = std::move(v2);
    REQUIRE(v1.initialized());
    REQUIRE_FALSE(v2.initialized());
}
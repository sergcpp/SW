#include <catch.hpp>

#include "../Signal_.h"

namespace {
    double static_func(int param1, float param2) {
        return param1 + param2;
    }

    class AAA {
    public:
        double member_func(int param1, float param2) {
            return param1 - param2;
        }

        double member_const_func(int param1, float param2) const {
            return param1 - 0.5f * param2;
        }
    };
}

TEST_CASE("Delegate bind", "[Delegate]") {
    SECTION("Static func") {
        sys::Delegate<double(int, float)> del;
        del.Bind<::static_func>();
        REQUIRE(del(1, 2.4f) == Approx(3.4));
    }

    SECTION("Member func") {
        sys::Delegate<double(int, float)> del;
        AAA a;
        del.Bind<AAA, &AAA::member_func>(&a);
        REQUIRE(del(2, 1.4f) == Approx(0.6));
    }

    SECTION("Member const func") {
        sys::Delegate<double(int, float)> del;
        AAA a;
        const AAA &_a = a;
        del.Bind<AAA, &AAA::member_const_func>(&_a);
        REQUIRE(del(2, 1.4f) == Approx(1.3));
    }
}

TEST_CASE("Signal connect", "[Signal]") {
    sys::Signal<double(int, float)> sig;

	AAA a;

	sig.Connect<::static_func>();
	sig.Connect<AAA, &AAA::member_func>(&a);
	sig.Connect<AAA, &AAA::member_const_func>(&a);

	REQUIRE(sig.size() == 3);

	REQUIRE(sig.FireOne(0, 5, 2.2f) == Approx(7.2));
	REQUIRE(sig.FireOne(1, 5, 2.2f) == Approx(2.8));
	REQUIRE(sig.FireOne(2, 5, 2.2f) == Approx(3.9));

	REQUIRE(sig.FireL(4, 1.0f) == Approx(3.5));

	std::vector<double> result = sig.FireV(4, 0.3f);
	REQUIRE(result.size() == 3);
	REQUIRE(result[0] == Approx(4.3));
	REQUIRE(result[1] == Approx(3.7));
	REQUIRE(result[2] == Approx(3.85));
}